# User Acceptance Testing (UAT) Document
## Stocks Data Pipeline — Job ID: 1008498738955147

---

### 1. Document Information

| Field | Value |
| --- | --- |
| Document Title | Stocks Pipeline UAT Document |
| Job Name | stocks |
| Job ID | 1008498738955147 |
| Pipeline Owner | rishabhr366@gmail.com |
| Environment | dev |
| Schedule | Daily (every 1 day, UNPAUSED) |
| Compute | Serverless (auto-selected) |
| Failure Notifications | Email to rishabhr366@gmail.com |
| UAT Date | October 15, 2026 |
| UAT Status | ✅ PASSED |

---

### 2. Pipeline Overview

The Stocks Data Pipeline is a 5-task Lakeflow Job that fetches daily stock market data from Yahoo Finance, cleans and transforms it, registers it in Unity Catalog with full metadata, applies governance policies with compliance validation, and validates the complete data lineage chain.

**Pipeline Flow:**

```
api_fetch → data_cleaning → unity_catalog_register → governance_policies → lineage_validation
```

**Target Table:** `workspace.dev.stock_daily_data`

**Schema:**

| Column | Type | Comment |
| --- | --- | --- |
| Stock | string | Stock ticker symbol (e.g., INFY.NS, RELIANCE.NS, TCS.NS) |
| Open | double | Opening price in INR, rounded to 2 decimal places |
| High | double | Intraday high price in INR, rounded to 2 decimal places |
| Low | double | Intraday low price in INR, rounded to 2 decimal places |
| Close | double | Closing price in INR, rounded to 2 decimal places |
| Volume | long | Daily trading volume (number of shares) |
| fetch_date | date | Date the stock data was fetched |

**Tickers:** RELIANCE.NS, TCS.NS, INFY.NS

---

### 3. Task Descriptions

#### Task 1: api_fetch

| Field | Value |
| --- | --- |
| Task Key | api_fetch |
| Type | Notebook (Workspace) |
| Notebook | /Workspace/Users/rishabhr366@gmail.com/api fetch |
| Environment Key | yfinance_env (pre-installs yfinance) |
| Parameters | environment=dev, tickers=RELIANCE.NS,TCS.NS,INFY.NS |
| Depends On | None (first task) |
| Timeout | None (0 = unlimited) |

**Functionality:**
- Reads the `environment` and `tickers` widget parameters
- Uses `yfinance` library to download 1-day OHLCV data from Yahoo Finance
- Restructures data into rows (one per ticker) with columns: Stock, Open, High, Low, Close, Volume
- Converts to Spark DataFrame, adds `fetch_date` column (current date)
- Appends to `{environment}.stock_daily_data` Delta table
- Error handling: try/except on download, empty-data check with RuntimeError

#### Task 2: data_cleaning

| Field | Value |
| --- | --- |
| Task Key | data_cleaning |
| Type | Notebook (Workspace) |
| Notebook | /Workspace/Users/rishabhr366@gmail.com/transform |
| Parameters | environment=dev |
| Depends On | api_fetch |

**Functionality:**
- Reads from `{environment}.stock_daily_data`
- Deduplicates by Stock + fetch_date (keeps first occurrence)
- Rounds price columns (Open, High, Low, Close) to 2 decimal places
- Overwrites the table with cleaned data

#### Task 3: unity_catalog_register

| Field | Value |
| --- | --- |
| Task Key | unity_catalog_register |
| Type | Notebook (Workspace) |
| Notebook | /Workspace/Users/rishabhr366@gmail.com/unity_catalog_register |
| Parameters | environment=dev |
| Depends On | data_cleaning |

**Functionality:**
- Reads cleaned data from `{environment}.stock_daily_data`
- Resolves current catalog and constructs full 3-part UC name
- Writes as managed UC table with `overwriteSchema` option
- Sets table TBLPROPERTIES: comment, pipeline_stage, environment, source_task
- Sets column comments on all 7 columns
- Sets task output values: registered_table_name, registered_catalog, registered_schema, row_count

#### Task 4: governance_policies

| Field | Value |
| --- | --- |
| Task Key | governance_policies |
| Type | Notebook (Workspace) |
| Notebook | /Workspace/Users/rishabhr366@gmail.com/governance_policies |
| Parameters | environment=dev |
| Depends On | unity_catalog_register |

**Functionality:**
- Retrieves upstream task values (registered_table_name, row_count, etc.)
- Applies 8 table-level governance tags: data_domain, data_classification, governance_status, pipeline_stage, environment_tag, owner_team, retention_policy, pii_flag
- Applies 4 governance TBLPROPERTIES: governance.applied_at, governance.policy_version, governance.applied_by, governance.compliance_framework
- Applies column-level tags on all 7 columns (data_type_tag, sensitivity/pii_flag)
- Validates 5 compliance rules:
  1. Row count matches upstream
  2. No nulls in key columns (Stock, Close)
  3. Non-negative prices
  4. Non-negative volume
  5. Governance properties applied (via SHOW TBLPROPERTIES)
- Sets task output values: governance_status, applied_tags, policy_version, compliance_rules_passed, governed_table_name

#### Task 5: lineage_validation

| Field | Value |
| --- | --- |
| Task Key | lineage_validation |
| Type | Notebook (Workspace) |
| Notebook | /Workspace/Users/rishabhr366@gmail.com/lineage_validation |
| Parameters | environment=dev |
| Depends On | governance_policies |

**Functionality:**
- Retrieves upstream task values from both unity_catalog_register and governance_policies
- Validates 12 checks:
  1. Table exists in Unity Catalog
  2. Schema matches expected (7 columns with correct types)
  3. Row count matches upstream
  4. All columns have comments
  5. Governance table properties exist
  6. Upstream governance status is compliant
  7. Upstream compliance rules passed
  8. No nulls in key columns (Stock, Close)
  9. Non-negative prices
  10. Valid date range (fetch_date not null)
  11. Unique stock+date combinations (no duplicates)
  12. Distinct stock symbols present
- Prints comprehensive lineage validation report
- Sets task output values: lineage_validated, validation_summary, table_name, row_count, distinct_stocks, date_range
- Raises RuntimeError if any check fails (fail-fast behavior)

---

### 4. UAT Test Scenarios

#### 4.1 End-to-End Pipeline Execution

| Test ID | UAT-001 |
| --- | --- |
| Test Name | Full pipeline execution — all tasks succeed |
| Description | Trigger a manual run of the job and verify all 5 tasks complete with SUCCESS |
| Pre-conditions | Job is UNPAUSED, serverless compute available, Yahoo Finance API accessible |
| Test Steps | 1. Trigger `jobs run-now 1008498738955147` 2. Wait for all tasks to complete 3. Verify each task state is SUCCESS |
| Expected Result | All 5 tasks complete with result_state=SUCCESS |
| Actual Result | ✅ PASSED — Run 91926228366836: all 5 tasks SUCCESS, total 115s |
| Pass/Fail | PASS |

#### 4.2 Task Dependency Chain

| Test ID | UAT-002 |
| --- | --- |
| Test Name | Task dependency chain executes in correct order |
| Description | Verify tasks execute sequentially per the dependency chain |
| Pre-conditions | Job triggered successfully |
| Test Steps | 1. Review task start/end times from run output 2. Verify each task starts only after its upstream completes |
| Expected Result | api_fetch → data_cleaning → unity_catalog_register → governance_policies → lineage_validation (sequential) |
| Actual Result | ✅ PASSED — Confirmed via run 91926228366836 task timestamps |
| Pass/Fail | PASS |

#### 4.3 api_fetch — Data Retrieval

| Test ID | UAT-003 |
| --- | --- |
| Test Name | Stock data fetched from Yahoo Finance successfully |
| Description | Verify yfinance downloads OHLCV data for all 3 tickers and writes to Delta table |
| Pre-conditions | Yahoo Finance API accessible, yfinance_env environment active |
| Test Steps | 1. Run job 2. Check api_fetch task output 3. Query `SELECT * FROM dev.stock_daily_data ORDER BY fetch_date DESC LIMIT 3` |
| Expected Result | 3 rows appended (one per ticker) with valid OHLCV values and today's fetch_date |
| Actual Result | ✅ PASSED — 3 records saved per run, data confirmed in table |
| Pass/Fail | PASS |

#### 4.4 api_fetch — Error Handling

| Test ID | UAT-004 |
| --- | --- |
| Test Name | api_fetch fails gracefully on Yahoo Finance errors |
| Description | Verify error handling catches download failures and empty data with clear error messages |
| Pre-conditions | N/A (code review validation) |
| Test Steps | 1. Review notebook code 2. Verify try/except wraps yf.download() 3. Verify empty data check raises RuntimeError |
| Expected Result | RuntimeErrors raised with descriptive messages for both download failure and empty data scenarios |
| Actual Result | ✅ PASSED — try/except with RuntimeError implemented, data.empty check present |
| Pass/Fail | PASS |

#### 4.5 api_fetch — Performance

| Test ID | UAT-005 |
| --- | --- |
| Test Name | api_fetch completes in under 60 seconds |
| Description | Verify the job environment eliminates pip install overhead and api_fetch runs efficiently |
| Pre-conditions | yfinance_env environment configured with yfinance dependency |
| Test Steps | 1. Run job 2. Check api_fetch execution_duration in run output |
| Expected Result | execution_duration < 60,000 ms (60 seconds) |
| Actual Result | ✅ PASSED — 32,000 ms (32s) in run 91926228366836 (was 665,000 ms before optimization) |
| Pass/Fail | PASS |

#### 4.6 data_cleaning — Deduplication

| Test ID | UAT-006 |
| --- | --- |
| Test Name | Deduplication removes duplicate Stock+fetch_date rows |
| Description | Verify data_cleaning removes duplicates and rounds prices to 2 decimal places |
| Pre-conditions | api_fetch has written data to dev.stock_daily_data |
| Test Steps | 1. Run job 2. Query `SELECT Stock, fetch_date, COUNT(*) FROM dev.stock_daily_data GROUP BY Stock, fetch_date HAVING COUNT(*) > 1` |
| Expected Result | No duplicate rows found after data_cleaning runs |
| Actual Result | ✅ PASSED — lineage_validation check 'unique_stock_date' confirmed 132 rows = 132 unique combinations |
| Pass/Fail | PASS |

#### 4.7 unity_catalog_register — Table Registration

| Test ID | UAT-007 |
| --- | --- |
| Test Name | Table registered in Unity Catalog with full 3-part name |
| Description | Verify the table is accessible via `workspace.dev.stock_daily_data` with correct schema and metadata |
| Pre-conditions | unity_catalog_register task completed successfully |
| Test Steps | 1. Run `SHOW TBLPROPERTIES workspace.dev.stock_daily_data` 2. Verify governance properties exist 3. Check column comments via DESCRIBE |
| Expected Result | Table exists with 7 columns, 4 governance TBLPROPERTIES, column comments on all columns |
| Actual Result | ✅ PASSED — 132 rows, 7 columns with comments, 4 governance properties confirmed |
| Pass/Fail | PASS |

#### 4.8 unity_catalog_register — Task Output Values

| Test ID | UAT-008 |
| --- | --- |
| Test Name | Task output values are set for downstream tasks |
| Description | Verify registered_table_name, registered_catalog, registered_schema, row_count are available to downstream tasks |
| Pre-conditions | unity_catalog_register completed |
| Test Steps | 1. Review notebook code for dbutils.jobs.taskValues.set calls 2. Verify governance_policies retrieves these values |
| Expected Result | 4 task output values set: registered_table_name, registered_catalog, registered_schema, row_count |
| Actual Result | ✅ PASSED — Values set and retrieved by downstream tasks (standalone fallback also works) |
| Pass/Fail | PASS |

#### 4.9 governance_policies — Tag Application

| Test ID | UAT-009 |
| --- | --- |
| Test Name | Governance tags applied to table and columns |
| Description | Verify 8 table-level tags and 7 column-level tag sets are applied |
| Pre-conditions | governance_policies task completed |
| Test Steps | 1. Run `SHOW TBLPROPERTIES workspace.dev.stock_daily_data` 2. Verify governance.* properties exist |
| Expected Result | 8 table-level tags + 7 column-level tag sets + 4 governance TBLPROPERTIES |
| Actual Result | ✅ PASSED — 4 governance properties found via SHOW TBLPROPERTIES, 8 tags + 7 column tags applied |
| Pass/Fail | PASS |

#### 4.10 governance_policies — Compliance Rules

| Test ID | UAT-010 |
| --- | --- |
| Test Name | All 5 compliance rules pass with COMPLIANT status |
| Description | Verify governance compliance validation passes all rules |
| Pre-conditions | governance_policies task completed |
| Test Steps | 1. Review task output 2. Verify governance_status=compliant 3. Verify compliance_rules_passed=true |
| Expected Result | governance_status=compliant, compliance_rules_passed=true, all 5 rules PASS |
| Actual Result | ✅ PASSED — All 5 rules PASS, status: COMPLIANT |
| Pass/Fail | PASS |

**Compliance Rules:**

| # | Rule | Description |
| --- | --- | --- |
| 1 | row_count_match | Row count matches upstream unity_catalog_register |
| 2 | no_nulls_key_columns | No nulls in Stock and Close columns |
| 3 | non_negative_prices | All price columns (Open, High, Low, Close) are non-negative |
| 4 | non_negative_volume | Volume column has no negative values |
| 5 | governance_tags_applied | Governance TBLPROPERTIES exist on the table |

#### 4.11 lineage_validation — Full Validation

| Test ID | UAT-011 |
| --- | --- |
| Test Name | All 12 lineage validation checks pass |
| Description | Verify the lineage validation notebook checks all aspects of the pipeline |
| Pre-conditions | lineage_validation task completed |
| Test Steps | 1. Review task output 2. Verify lineage_validated=true 3. Verify all 12 checks PASS |
| Expected Result | lineage_validated=true, 12/12 checks PASS |
| Actual Result | ✅ PASSED — 12/12 checks PASS, lineage_validated=True |
| Pass/Fail | PASS |

**Validation Checks:**

| # | Check | Description |
| --- | --- | --- |
| 1 | table_exists | Table exists in Unity Catalog with data |
| 2 | schema_match | All 7 expected columns present with correct types |
| 3 | row_count_match | Row count matches upstream task value |
| 4 | column_comments | All 7 columns have metadata comments |
| 5 | governance_properties | Governance TBLPROPERTIES exist on table |
| 6 | upstream_governance_status | Upstream governance_status is compliant |
| 7 | upstream_compliance | Upstream compliance_rules_passed is true |
| 8 | no_nulls_key_columns | No nulls in Stock and Close columns |
| 9 | non_negative_prices | All price columns are non-negative |
| 10 | valid_date_range | fetch_date is not null and has valid range |
| 11 | unique_stock_date | No duplicate Stock+fetch_date combinations |
| 12 | distinct_stocks | Multiple distinct stock symbols present |

#### 4.12 lineage_validation — Fail-Fast Behavior

| Test ID | UAT-012 |
| --- | --- |
| Test Name | Lineage validation raises error on failure |
| Description | Verify the notebook raises RuntimeError if any check fails, causing the job to fail |
| Pre-conditions | N/A (code review validation) |
| Test Steps | 1. Review notebook code 2. Verify `raise RuntimeError(...)` is present when all_valid is False |
| Expected Result | RuntimeError raised with list of failed checks when any validation fails |
| Actual Result | ✅ PASSED — RuntimeError raised with failed_checks list in final cell |
| Pass/Fail | PASS |

#### 4.13 Schedule Configuration

| Test ID | UAT-013 |
| --- | --- |
| Test Name | Daily schedule is active and configured correctly |
| Description | Verify the job runs on a daily schedule |
| Pre-conditions | Job exists with periodic trigger |
| Test Steps | 1. Read job settings 2. Verify trigger.periodic.interval=1, unit=DAYS, pause_status=UNPAUSED |
| Expected Result | Daily schedule, UNPAUSED, interval=1, unit=DAYS |
| Actual Result | ✅ PASSED — Confirmed in job settings: periodic interval=1, unit=DAYS, UNPAUSED |
| Pass/Fail | PASS |

#### 4.14 Failure Notifications

| Test ID | UAT-014 |
| --- | --- |
| Test Name | Email notifications configured for failures |
| Description | Verify failure email notifications are sent to the pipeline owner |
| Pre-conditions | Job exists with email_notifications configured |
| Test Steps | 1. Read job settings 2. Verify email_notifications.on_failure includes rishabhr366@gmail.com |
| Expected Result | on_failure email list includes rishabhr366@gmail.com |
| Actual Result | ✅ PASSED — email_notifications.on_failure: [rishabhr366@gmail.com] |
| Pass/Fail | PASS |

#### 4.15 Task Value Passing Between Tasks

| Test ID | UAT-015 |
| --- | --- |
| Test Name | Task output values flow correctly between dependent tasks |
| Description | Verify upstream task values are retrievable by downstream tasks via dbutils.jobs.taskValues |
| Pre-conditions | Pipeline run completed successfully |
| Test Steps | 1. Review unity_catalog_register sets: registered_table_name, registered_catalog, registered_schema, row_count 2. Review governance_policies sets: governance_status, applied_tags, policy_version, compliance_rules_passed, governed_table_name 3. Review lineage_validation retrieves from both upstream tasks |
| Expected Result | All task values set and retrieved successfully, standalone fallback works when not in job context |
| Actual Result | ✅ PASSED — Values flow correctly through the pipeline; standalone fallback confirmed during notebook testing |
| Pass/Fail | PASS |

---

### 5. Performance Benchmarks

| Metric | Before Optimization | After Optimization | Improvement |
| --- | --- | --- | --- |
| api_fetch execution time | 665,000 ms (665s) | 32,000 ms (32s) | 95% faster |
| Total pipeline duration | 754,182 ms (12.5 min) | 114,796 ms (1.9 min) | 85% faster |
| pip install per run | ~500-640s (22+ dependencies) | 0s (pre-installed in env) | Eliminated |
| Unnecessary Spark actions | 1 (spark_df.count after write) | 0 (uses len(df_final)) | Eliminated |

**Optimization Applied:**
- Moved `yfinance` from `%pip install` in notebook to job environment (`yfinance_env`) pre-install
- Removed unnecessary `spark_df.count()` after write
- Added error handling and empty-data check to yf.download()

---

### 6. Test Execution Summary

| Category | Total Tests | Passed | Failed | Blocked |
| --- | --- | --- | --- | --- |
| End-to-End | 2 | 2 | 0 | 0 |
| api_fetch | 3 | 3 | 0 | 0 |
| data_cleaning | 1 | 1 | 0 | 0 |
| unity_catalog_register | 2 | 2 | 0 | 0 |
| governance_policies | 2 | 2 | 0 | 0 |
| lineage_validation | 2 | 2 | 0 | 0 |
| Configuration | 2 | 2 | 0 | 0 |
| Integration | 1 | 1 | 0 | 0 |
| **Total** | **15** | **15** | **0** | **0** |

**Overall UAT Result: ✅ PASSED (15/15 tests passed)**

---

### 7. Known Limitations and Assumptions

1. **Yahoo Finance API dependency** — The pipeline relies on the free Yahoo Finance API via yfinance. If Yahoo changes their API or enforces rate limits, api_fetch may fail. The error handling will surface a clear RuntimeError.
2. **Market hours** — `yf.download(period="1d")` fetches today's data. If the job runs outside market hours or on weekends/holidays, the API may return empty data. The empty-data check will raise a RuntimeError.
3. **Append mode** — api_fetch appends data to `dev.stock_daily_data` on each run. The data_cleaning task deduplicates by Stock+fetch_date, but historical duplicates from multiple same-day runs are cleaned only on the next pipeline execution.
4. **Single environment** — The pipeline currently runs in the `dev` environment only. A `prod` environment would require corresponding catalog/schema setup.
5. **Serverless compute** — The job runs on serverless compute. Task-level compute configuration (cluster size, runtime version) is auto-selected by Databricks.
6. **No retry configuration** — The job does not have explicit max_retries or retry_on_timeout set. Serverless auto-optimization may retry transient failures automatically.

---

### 8. Sign-Off

| Role | Name | Date | Status |
| --- | --- | --- | --- |
| Pipeline Developer | rishabhr366@gmail.com | October 15, 2026 | ✅ Approved |
| UAT Reviewer | | | |
| Production Approver | | | |

---

### 9. Appendix — Job Configuration Summary

```json
{
  "job_id": 1008498738955147,
  "name": "stocks",
  "trigger": {
    "pause_status": "UNPAUSED",
    "periodic": { "interval": 1, "unit": "DAYS" }
  },
  "max_concurrent_runs": 1,
  "format": "MULTI_TASK",
  "queue": { "enabled": true },
  "performance_target": "PERFORMANCE_OPTIMIZED",
  "environments": [
    {
      "environment_key": "yfinance_env",
      "spec": { "client": "2", "dependencies": ["yfinance"] }
    }
  ],
  "email_notifications": {
    "on_failure": ["rishabhr366@gmail.com"]
  },
  "tasks": [
    { "task_key": "api_fetch", "environment_key": "yfinance_env" },
    { "task_key": "data_cleaning", "depends_on": ["api_fetch"] },
    { "task_key": "unity_catalog_register", "depends_on": ["data_cleaning"] },
    { "task_key": "governance_policies", "depends_on": ["unity_catalog_register"] },
    { "task_key": "lineage_validation", "depends_on": ["governance_policies"] }
  ]
}
```

---

*This UAT document was generated based on pipeline testing conducted on October 15, 2026. All tests passed against run ID 91926228366836.*