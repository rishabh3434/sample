# Databricks notebook source
# DBTITLE 1,Governance Policies Title
# MAGIC %md
# MAGIC # Governance Policies
# MAGIC
# MAGIC This notebook applies governance policies to the registered Unity Catalog table (`workspace.dev.stock_daily_data`). It sets data classification tags, column-level governance metadata, validates compliance rules, and sets task output values for the downstream `lineage_validation` task.

# COMMAND ----------

# DBTITLE 1,Environment Config & Read Registered Table
# Environment configuration - reads from job parameter or defaults to dev
dbutils.widgets.text("environment", "dev", "Environment (dev/prod)")
environment = dbutils.widgets.get("environment")

print(f"Running in {environment.upper()} environment")

# Retrieve upstream task output values from unity_catalog_register
# Falls back to constructing the table name when running standalone
try:
    registered_table = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="registered_table_name")
    registered_catalog = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="registered_catalog")
    registered_schema = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="registered_schema")
    upstream_row_count = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="row_count")
    print(f"Retrieved from upstream: table={registered_table}, catalog={registered_catalog}, schema={registered_schema}, rows={upstream_row_count}")
except Exception:
    current_catalog = spark.catalog.currentCatalog()
    registered_catalog = current_catalog
    registered_schema = environment
    registered_table = f"{current_catalog}.{environment}.stock_daily_data"
    upstream_row_count = None
    print(f"Standalone mode: using table={registered_table}")

# Load the registered table
df = spark.table(registered_table)
current_row_count = df.count()
print(f"Current row count in registered table: {current_row_count}")

# COMMAND ----------

# DBTITLE 1,Apply Governance Tags & Properties
from datetime import datetime, timezone

# Apply table-level governance tags (free-form tags)
governance_tags = {
    "data_domain": "financial_markets",
    "data_classification": "internal",
    "governance_status": "governed",
    "pipeline_stage": "governance_policies",
    "environment_tag": environment,
    "owner_team": "data_engineering",
    "retention_policy": "2_years",
    "pii_flag": "false"
}

tag_pairs = ", ".join([f"'{k}'='{v}'" for k, v in governance_tags.items()])
spark.sql(f"ALTER TABLE {registered_table} SET TAGS ({tag_pairs})")
print(f"Applied {len(governance_tags)} table-level governance tags to {registered_table}")

# Set governance-related table properties
applied_at = datetime.now(timezone.utc).isoformat()
spark.sql(f"""
    ALTER TABLE {registered_table}
    SET TBLPROPERTIES (
        'governance.applied_at' = '{applied_at}',
        'governance.policy_version' = '1.0',
        'governance.applied_by' = 'governance_policies_task',
        'governance.compliance_framework' = 'internal_data_policy_v1'
    )
""")
print("Governance table properties set successfully")

# Apply column-level tags for data classification
column_tags = {
    "Stock": {"data_type_tag": "identifier", "pii_flag": "false"},
    "Open": {"data_type_tag": "financial_metric", "sensitivity": "low"},
    "High": {"data_type_tag": "financial_metric", "sensitivity": "low"},
    "Low": {"data_type_tag": "financial_metric", "sensitivity": "low"},
    "Close": {"data_type_tag": "financial_metric", "sensitivity": "low"},
    "Volume": {"data_type_tag": "financial_metric", "sensitivity": "low"},
    "fetch_date": {"data_type_tag": "metadata", "sensitivity": "none"}
}

for col_name, tags in column_tags.items():
    col_tag_pairs = ", ".join([f"'{k}'='{v}'" for k, v in tags.items()])
    spark.sql(f"ALTER TABLE {registered_table} ALTER COLUMN {col_name} SET TAGS ({col_tag_pairs})")

print(f"Applied column-level governance tags to {len(column_tags)} columns")

# COMMAND ----------

# DBTITLE 1,Compliance Validation
# Compliance validation - verify data integrity and governance rules
compliance_results = []
all_passed = True

# Rule 1: Row count matches upstream
if upstream_row_count is not None:
    row_count_match = (current_row_count == upstream_row_count)
    compliance_results.append({"rule": "row_count_match", "passed": row_count_match, "detail": f"Expected {upstream_row_count}, got {current_row_count}"})
    print(f"Rule 1 - Row count match: {'PASS' if row_count_match else 'FAIL'} (expected {upstream_row_count}, got {current_row_count})")
    if not row_count_match:
        all_passed = False
else:
    compliance_results.append({"rule": "row_count_match", "passed": True, "detail": "Skipped (no upstream value)"})
    print("Rule 1 - Row count match: SKIPPED (no upstream value)")

# Rule 2: No null values in key columns (Stock, Close)
null_stock = df.filter("Stock IS NULL").count()
null_close = df.filter("Close IS NULL").count()
no_nulls = (null_stock == 0 and null_close == 0)
compliance_results.append({"rule": "no_nulls_key_columns", "passed": no_nulls, "detail": f"Stock nulls={null_stock}, Close nulls={null_close}"})
print(f"Rule 2 - No nulls in key columns: {'PASS' if no_nulls else 'FAIL'} (Stock nulls={null_stock}, Close nulls={null_close})")
if not no_nulls:
    all_passed = False

# Rule 3: All price columns are non-negative
negative_prices = df.filter("Open < 0 OR High < 0 OR Low < 0 OR Close < 0").count()
non_neg_prices = (negative_prices == 0)
compliance_results.append({"rule": "non_negative_prices", "passed": non_neg_prices, "detail": f"Negative price rows={negative_prices}"})
print(f"Rule 3 - Non-negative prices: {'PASS' if non_neg_prices else 'FAIL'} (negative rows={negative_prices})")
if not non_neg_prices:
    all_passed = False

# Rule 4: Volume is non-negative
negative_volume = df.filter("Volume < 0").count()
non_neg_volume = (negative_volume == 0)
compliance_results.append({"rule": "non_negative_volume", "passed": non_neg_volume, "detail": f"Negative volume rows={negative_volume}"})
print(f"Rule 4 - Non-negative volume: {'PASS' if non_neg_volume else 'FAIL'} (negative rows={negative_volume})")
if not non_neg_volume:
    all_passed = False

# Rule 5: Verify governance properties were applied via SHOW TBLPROPERTIES
props_df = spark.sql(f"SHOW TBLPROPERTIES {registered_table}")
gov_props = props_df.filter("key LIKE '%governance%'").collect()
tags_ok = len(gov_props) > 0
compliance_results.append({"rule": "governance_tags_applied", "passed": tags_ok, "detail": f"Found {len(gov_props)} governance properties in table metadata"})
print(f"Rule 5 - Governance tags applied: {'PASS' if tags_ok else 'FAIL'} (found {len(gov_props)} governance properties)")
if not tags_ok:
    all_passed = False

governance_status = "compliant" if all_passed else "non_compliant"
print(f"\nOverall governance status: {governance_status.upper()}")

# COMMAND ----------

# DBTITLE 1,Summary & Task Output Values
# Print governance summary
print("=" * 60)
print("Governance Policies Summary")
print("=" * 60)
print(f"Table: {registered_table}")
print(f"Catalog: {registered_catalog}")
print(f"Schema: {registered_schema}")
print(f"Row count: {current_row_count}")
print(f"Governance status: {governance_status}")
print(f"Policy version: 1.0")
print(f"Tags applied: {len(governance_tags)} table-level + {len(column_tags)} column-level")
print(f"Compliance rules checked: {len(compliance_results)}")
print(f"All rules passed: {all_passed}")
print("\nApplied tags:")
for k, v in governance_tags.items():
    print(f"  {k} = {v}")
print("\nCompliance results:")
for r in compliance_results:
    status = "PASS" if r["passed"] else "FAIL"
    print(f"  [{status}] {r['rule']}: {r['detail']}")
print("=" * 60)

# Set task output values for downstream lineage_validation task
applied_tags_list = list(governance_tags.keys())
dbutils.jobs.taskValues.set(key="governance_status", value=governance_status)
dbutils.jobs.taskValues.set(key="applied_tags", value=applied_tags_list)
dbutils.jobs.taskValues.set(key="policy_version", value="1.0")
dbutils.jobs.taskValues.set(key="compliance_rules_passed", value=all_passed)
dbutils.jobs.taskValues.set(key="governed_table_name", value=registered_table)

print(f"Task output values set: governance_status={governance_status}")
print("Governance policies applied successfully!")