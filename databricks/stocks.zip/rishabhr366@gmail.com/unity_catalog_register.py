# Databricks notebook source
# DBTITLE 1,Unity Catalog Registration Title
# MAGIC %md
# MAGIC # Unity Catalog Registration
# MAGIC
# MAGIC This notebook reads cleaned stock data from the `data_cleaning` task and registers it as a managed Unity Catalog table with full schema metadata, column comments, and table properties. It sets task output values for downstream tasks.

# COMMAND ----------

# DBTITLE 1,Environment Config & Read Cleaned Data
# Environment configuration - reads from job parameter or defaults to dev
dbutils.widgets.text("environment", "dev", "Environment (dev/prod)")
environment = dbutils.widgets.get("environment")

print(f"Running in {environment.upper()} environment")

# Read the cleaned stock data produced by the data_cleaning task
source_table = f"{environment}.stock_daily_data"
print(f"Reading cleaned data from: {source_table}")

df_cleaned = spark.table(source_table)
row_count = df_cleaned.count()
print(f"Loaded {row_count} rows from {source_table}")

# Display schema for reference
print(f"Schema: {df_cleaned.schema.simpleString()}")

# COMMAND ----------

# DBTITLE 1,Register UC Table with Metadata
# Register the cleaned data as a Unity Catalog table with full metadata
# Resolve the current catalog to construct the full three-part UC name
current_catalog = spark.catalog.currentCatalog()
table_name = f"{current_catalog}.{environment}.stock_daily_data"
print(f"Full Unity Catalog table name: {table_name}")

# Ensure the schema exists (create if needed)
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {current_catalog}.{environment}")

# Write the cleaned data as a managed UC table (create or replace)
df_cleaned.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(table_name)

print(f"Successfully registered table: {table_name}")

# Set table description
spark.sql(f"""
    ALTER TABLE {table_name} 
    SET TBLPROPERTIES (
        'comment' = 'Cleaned daily stock market data - deduplicated and price-rounded. Registered by unity_catalog_register task.',
        'pipeline_stage' = 'unity_catalog_register',
        'environment' = '{environment}',
        'source_task' = 'data_cleaning'
    )
""")

# Set column comments
column_comments = {
    'Stock': 'Stock ticker symbol (e.g., INFY.NS, RELIANCE.NS, TCS.NS)',
    'Open': 'Opening price in INR, rounded to 2 decimal places',
    'High': 'Intraday high price in INR, rounded to 2 decimal places',
    'Low': 'Intraday low price in INR, rounded to 2 decimal places',
    'Close': 'Closing price in INR, rounded to 2 decimal places',
    'Volume': 'Daily trading volume (number of shares)',
    'fetch_date': 'Date the stock data was fetched'
}

for col_name, comment in column_comments.items():
    spark.sql(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} COMMENT '{comment}'")

print("Table properties and column comments set successfully")

# COMMAND ----------

# DBTITLE 1,Summary & Task Output Values
# Print summary of the registered UC table
print("=" * 60)
print("Unity Catalog Registration Summary")
print("=" * 60)
print(f"Table: {table_name}")
print(f"Catalog: {current_catalog}")
print(f"Schema: {environment}")
print(f"Table: stock_daily_data")
print(f"Row count: {row_count}")
location_result = spark.sql(f"DESCRIBE TABLE EXTENDED {table_name}").filter("col_name == 'Location'").select("data_type").collect()
table_location = location_result[0][0] if location_result else "N/A"
print(f"Location: {table_location}")
print("\nSchema:")
df_registered = spark.table(table_name)
for field in df_registered.schema.fields:
    print(f"  {field.name}: {field.dataType.simpleString()}")
print("\nSample data:")
display(df_registered.limit(5))
print("=" * 60)

# Set task output values for downstream tasks (governance_policies, lineage_validation)
dbutils.jobs.taskValues.set(key="registered_table_name", value=table_name)
dbutils.jobs.taskValues.set(key="registered_catalog", value=current_catalog)
dbutils.jobs.taskValues.set(key="registered_schema", value=environment)
dbutils.jobs.taskValues.set(key="row_count", value=row_count)

print(f"Task output values set: registered_table_name={table_name}")
print("Unity Catalog registration complete!")