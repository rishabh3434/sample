# Databricks notebook source
# DBTITLE 1,Environment Configuration
# Environment configuration - reads from job parameter or defaults to dev
import os

# Get environment from widget (job parameter) or default to 'dev'
dbutils.widgets.text("environment", "dev", "Environment (dev/prod)")
environment = dbutils.widgets.get("environment")

print(f"Running in {environment.upper()} environment")
print(f"Table: {environment}.stock_daily_data")

# COMMAND ----------

# DBTITLE 1,api call
import yfinance as yf
import pandas as pd

# Get tickers from widget parameter
dbutils.widgets.text("tickers", "RELIANCE.NS,TCS.NS,INFY.NS", "Stock Tickers (comma-separated)")
tickers_param = dbutils.widgets.get("tickers")
tickers = [ticker.strip() for ticker in tickers_param.split(",")]

# Download stock data with error handling
try:
    data = yf.download(tickers, period="1d", interval="1d", threads=True)
except Exception as e:
    raise RuntimeError(f"Failed to download stock data from Yahoo Finance: {e}")

if data.empty:
    raise RuntimeError("Yahoo Finance returned empty data. Check if markets are open or tickers are valid.")

# Restructure: transpose to have stocks as rows and price metrics as columns
results = []
if len(tickers) == 1:
    # Single ticker: data has single-level columns
    ticker = tickers[0]
    row = {
        'Stock': ticker,
        'Open': data['Open'].values[0],
        'High': data['High'].values[0],
        'Low': data['Low'].values[0],
        'Close': data['Close'].values[0],
        'Volume': data['Volume'].values[0]
    }
    results.append(row)
else:
    # Multiple tickers: data has multi-level columns (metric, ticker)
    for ticker in tickers:
        row = {
            'Stock': ticker,
            'Open': data[('Open', ticker)].values[0],
            'High': data[('High', ticker)].values[0],
            'Low': data[('Low', ticker)].values[0],
            'Close': data[('Close', ticker)].values[0],
            'Volume': data[('Volume', ticker)].values[0]
        }
        results.append(row)

df_final = pd.DataFrame(results)
record_count = len(df_final)
print(f"Downloaded {record_count} stock records")
print(df_final.to_string())

# COMMAND ----------

# DBTITLE 1,Save to Delta Table
# Convert pandas DataFrame to Spark DataFrame
spark_df = spark.createDataFrame(df_final)

# Add date column for tracking
from pyspark.sql.functions import current_date
spark_df = spark_df.withColumn('fetch_date', current_date())

# Define table name
table_name = f'{environment}.stock_daily_data'

# Write to Delta table (will create if doesn't exist, append if exists)
spark_df.write.format('delta') \
    .mode('append') \
    .saveAsTable(table_name)

print(f'Successfully saved {record_count} records to table: {table_name}')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ${environment}.stock_daily_data order by fetch_date desc;