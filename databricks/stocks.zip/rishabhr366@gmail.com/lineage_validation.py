# Databricks notebook source
# DBTITLE 1,Lineage Validation Title
# MAGIC %md
# MAGIC # Lineage Validation
# MAGIC
# MAGIC This notebook validates the full data lineage chain: `api_fetch` → `data_cleaning` → `unity_catalog_register` → `governance_policies` → `lineage_validation`. It verifies the registered Unity Catalog table exists with the correct schema, column comments, governance tags, table properties, and data quality (no nulls, positive prices, valid dates, unique stock+date combinations). It sets task output values and raises an error if any validation fails.

# COMMAND ----------

# DBTITLE 1,Environment Config & Upstream Retrieval
# Environment configuration - reads from job parameter or defaults to dev
dbutils.widgets.text("environment", "dev", "Environment (dev/prod)")
environment = dbutils.widgets.get("environment")

print(f"Running in {environment.upper()} environment")

# Retrieve upstream task output values from unity_catalog_register and governance_policies
# Falls back to constructing values when running standalone
upstream = {}

# From unity_catalog_register
try:
    upstream["registered_table"] = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="registered_table_name")
    upstream["registered_catalog"] = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="registered_catalog")
    upstream["registered_schema"] = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="registered_schema")
    upstream["uc_row_count"] = dbutils.jobs.taskValues.get(taskKey="unity_catalog_register", key="row_count")
    print(f"Retrieved from unity_catalog_register: table={upstream['registered_table']}, rows={upstream['uc_row_count']}")
except Exception:
    current_catalog = spark.catalog.currentCatalog()
    upstream["registered_table"] = f"{current_catalog}.{environment}.stock_daily_data"
    upstream["registered_catalog"] = current_catalog
    upstream["registered_schema"] = environment
    upstream["uc_row_count"] = None
    print(f"Standalone mode (uc_register): using table={upstream['registered_table']}")

# From governance_policies
try:
    upstream["governance_status"] = dbutils.jobs.taskValues.get(taskKey="governance_policies", key="governance_status")
    upstream["applied_tags"] = dbutils.jobs.taskValues.get(taskKey="governance_policies", key="applied_tags")
    upstream["policy_version"] = dbutils.jobs.taskValues.get(taskKey="governance_policies", key="policy_version")
    upstream["compliance_passed"] = dbutils.jobs.taskValues.get(taskKey="governance_policies", key="compliance_rules_passed")
    upstream["governed_table"] = dbutils.jobs.taskValues.get(taskKey="governance_policies", key="governed_table_name")
    print(f"Retrieved from governance_policies: status={upstream['governance_status']}, policy_version={upstream['policy_version']}")
except Exception:
    upstream["governance_status"] = None
    upstream["applied_tags"] = None
    upstream["policy_version"] = None
    upstream["compliance_passed"] = None
    upstream["governed_table"] = upstream["registered_table"]
    print("Standalone mode (governance_policies): using defaults")

print(f"Target table for lineage validation: {upstream['registered_table']}")

# COMMAND ----------

# DBTITLE 1,Table Existence & Schema Validation
# Validate table existence and schema
table_name = upstream["registered_table"]
validation_results = []
all_valid = True

# Check 1: Table exists in Unity Catalog
try:
    df = spark.table(table_name)
    actual_row_count = df.count()
    validation_results.append({"check": "table_exists", "passed": True, "detail": f"Table {table_name} exists with {actual_row_count} rows"})
    print(f"[PASS] Table exists: {table_name} ({actual_row_count} rows)")
except Exception as e:
    validation_results.append({"check": "table_exists", "passed": False, "detail": str(e)})
    print(f"[FAIL] Table exists: {e}")
    all_valid = False
    raise RuntimeError(f"Table {table_name} does not exist or cannot be read: {e}")

# Check 2: Schema matches expected columns
expected_schema = {
    "Stock": "string",
    "Open": "double",
    "High": "double",
    "Low": "double",
    "Close": "double",
    "Volume": "long",
    "fetch_date": "date"
}

actual_fields = {f.name: f.dataType.simpleString() for f in df.schema.fields}
schema_match = True
missing_cols = []
type_mismatches = []

for col_name, expected_type in expected_schema.items():
    if col_name not in actual_fields:
        missing_cols.append(col_name)
        schema_match = False
    elif actual_fields[col_name] != expected_type:
        # Allow bigint as alias for long
        if not (expected_type == "long" and actual_fields[col_name] == "bigint"):
            type_mismatches.append(f"{col_name}: expected {expected_type}, got {actual_fields[col_name]}")
            schema_match = False

extra_cols = [c for c in actual_fields if c not in expected_schema]
if extra_cols:
    print(f"[WARN] Extra columns found: {extra_cols}")

if schema_match:
    validation_results.append({"check": "schema_match", "passed": True, "detail": f"All {len(expected_schema)} expected columns present with correct types"})
    print(f"[PASS] Schema match: all {len(expected_schema)} columns present with correct types")
else:
    detail_parts = []
    if missing_cols:
        detail_parts.append(f"Missing: {missing_cols}")
    if type_mismatches:
        detail_parts.append(f"Type mismatches: {type_mismatches}")
    validation_results.append({"check": "schema_match", "passed": False, "detail": "; ".join(detail_parts)})
    print(f"[FAIL] Schema match: {'; '.join(detail_parts)}")
    all_valid = False

# Check 3: Row count matches upstream (if available)
if upstream["uc_row_count"] is not None:
    count_match = (actual_row_count == upstream["uc_row_count"])
    validation_results.append({"check": "row_count_match", "passed": count_match, "detail": f"Expected {upstream['uc_row_count']}, got {actual_row_count}"})
    print(f"[{'PASS' if count_match else 'FAIL'}] Row count match: expected {upstream['uc_row_count']}, got {actual_row_count}")
    if not count_match:
        all_valid = False
else:
    validation_results.append({"check": "row_count_match", "passed": True, "detail": "Skipped (no upstream value)"})
    print("[PASS] Row count match: SKIPPED (no upstream value)")

# COMMAND ----------

# DBTITLE 1,Governance & Metadata Validation
# Validate column comments and governance metadata

# Check 4: All columns have comments
comments_ok = True
missing_comments = []
for field in df.schema.fields:
    comment = field.metadata.get("comment", None) if field.metadata else None
    if not comment:
        missing_comments.append(field.name)
        comments_ok = False

if comments_ok:
    validation_results.append({"check": "column_comments", "passed": True, "detail": f"All {len(df.schema.fields)} columns have comments"})
    print(f"[PASS] Column comments: all {len(df.schema.fields)} columns have comments")
else:
    validation_results.append({"check": "column_comments", "passed": False, "detail": f"Missing comments on: {missing_comments}"})
    print(f"[FAIL] Column comments: missing on {missing_comments}")
    all_valid = False

# Check 5: Governance table properties exist (via SHOW TBLPROPERTIES)
try:
    props_df = spark.sql(f"SHOW TBLPROPERTIES {table_name}")
    gov_props = props_df.filter("key LIKE '%governance%'").collect()
    gov_prop_count = len(gov_props)
    if gov_prop_count > 0:
        validation_results.append({"check": "governance_properties", "passed": True, "detail": f"Found {gov_prop_count} governance properties"})
        print(f"[PASS] Governance properties: found {gov_prop_count} governance properties")
    else:
        validation_results.append({"check": "governance_properties", "passed": False, "detail": "No governance properties found"})
        print("[FAIL] Governance properties: none found")
        all_valid = False
except Exception as e:
    validation_results.append({"check": "governance_properties", "passed": False, "detail": f"Error: {e}"})
    print(f"[FAIL] Governance properties: error - {e}")
    all_valid = False

# Check 6: Upstream governance status (if available)
if upstream["governance_status"] is not None:
    gov_ok = (upstream["governance_status"] == "compliant")
    validation_results.append({"check": "upstream_governance_status", "passed": gov_ok, "detail": f"Status: {upstream['governance_status']}"})
    print(f"[{'PASS' if gov_ok else 'FAIL'}] Upstream governance status: {upstream['governance_status']}")
    if not gov_ok:
        all_valid = False
else:
    validation_results.append({"check": "upstream_governance_status", "passed": True, "detail": "Skipped (no upstream value)"})
    print("[PASS] Upstream governance status: SKIPPED (no upstream value)")

# Check 7: Upstream compliance rules passed (if available)
if upstream["compliance_passed"] is not None:
    compliance_ok = upstream["compliance_passed"]
    validation_results.append({"check": "upstream_compliance", "passed": compliance_ok, "detail": f"compliance_rules_passed={compliance_ok}"})
    print(f"[{'PASS' if compliance_ok else 'FAIL'}] Upstream compliance rules: {compliance_ok}")
    if not compliance_ok:
        all_valid = False
else:
    validation_results.append({"check": "upstream_compliance", "passed": True, "detail": "Skipped (no upstream value)"})
    print("[PASS] Upstream compliance rules: SKIPPED (no upstream value)")

# COMMAND ----------

# DBTITLE 1,Data Quality Validation
# Data quality validation
from pyspark.sql.functions import col, count, when, min as spark_min, max as spark_max, countDistinct

# Check 8: No nulls in key columns (Stock, Close)
null_stock = df.filter(col("Stock").isNull()).count()
null_close = df.filter(col("Close").isNull()).count()
no_nulls = (null_stock == 0 and null_close == 0)
validation_results.append({"check": "no_nulls_key_columns", "passed": no_nulls, "detail": f"Stock nulls={null_stock}, Close nulls={null_close}"})
print(f"[{'PASS' if no_nulls else 'FAIL'}] No nulls in key columns: Stock nulls={null_stock}, Close nulls={null_close}")
if not no_nulls:
    all_valid = False

# Check 9: All price columns are non-negative
negative_prices = df.filter("Open < 0 OR High < 0 OR Low < 0 OR Close < 0").count()
non_neg = (negative_prices == 0)
validation_results.append({"check": "non_negative_prices", "passed": non_neg, "detail": f"Negative price rows={negative_prices}"})
print(f"[{'PASS' if non_neg else 'FAIL'}] Non-negative prices: {negative_prices} negative rows")
if not non_neg:
    all_valid = False

# Check 10: Valid date range (fetch_date not null and within reasonable bounds)
null_dates = df.filter(col("fetch_date").isNull()).count()
date_stats = df.select(spark_min("fetch_date").alias("min_date"), spark_max("fetch_date").alias("max_date")).collect()[0]
min_date = date_stats["min_date"]
max_date = date_stats["max_date"]
dates_valid = (null_dates == 0 and min_date is not None and max_date is not None)
validation_results.append({"check": "valid_date_range", "passed": dates_valid, "detail": f"Null dates={null_dates}, range={min_date} to {max_date}"})
print(f"[{'PASS' if dates_valid else 'FAIL'}] Valid date range: nulls={null_dates}, range={min_date} to {max_date}")
if not dates_valid:
    all_valid = False

# Check 11: Unique stock+date combinations (no duplicates)
total_rows = df.count()
unique_combos = df.select("Stock", "fetch_date").distinct().count()
no_duplicates = (total_rows == unique_combos)
validation_results.append({"check": "unique_stock_date", "passed": no_duplicates, "detail": f"Total rows={total_rows}, unique combos={unique_combos}"})
print(f"[{'PASS' if no_duplicates else 'FAIL'}] Unique stock+date: {total_rows} rows, {unique_combos} unique combinations")
if not no_duplicates:
    all_valid = False

# Check 12: Distinct stock symbols present
distinct_stocks = df.select(countDistinct("Stock")).collect()[0][0]
stocks_ok = (distinct_stocks > 0)
validation_results.append({"check": "distinct_stocks", "passed": stocks_ok, "detail": f"{distinct_stocks} distinct stock symbols"})
print(f"[{'PASS' if stocks_ok else 'FAIL'}] Distinct stocks: {distinct_stocks} symbols found")
if not stocks_ok:
    all_valid = False

# COMMAND ----------

# DBTITLE 1,Lineage Report & Task Output Values
# Print comprehensive lineage validation report
lineage_chain = ["api_fetch", "data_cleaning", "unity_catalog_register", "governance_policies", "lineage_validation"]

print("=" * 70)
print("LINEAGE VALIDATION REPORT")
print("=" * 70)
print(f"Pipeline: {' -> '.join(lineage_chain)}")
print(f"Table: {table_name}")
print(f"Catalog: {upstream['registered_catalog']}")
print(f"Schema: {upstream['registered_schema']}")
print(f"Row count: {actual_row_count}")
print(f"Date range: {min_date} to {max_date}")
print(f"Distinct stocks: {distinct_stocks}")
print()
print("Lineage Chain Status:")
for i, stage in enumerate(lineage_chain):
    marker = "DONE" if i < len(lineage_chain) - 1 or all_valid else "CHECK"
    print(f"  [{marker}] {stage}")
print()
print(f"Total checks performed: {len(validation_results)}")
print(f"All checks passed: {all_valid}")
print()
print("Detailed Results:")
for r in validation_results:
    status = "PASS" if r["passed"] else "FAIL"
    print(f"  [{status}] {r['check']}: {r['detail']}")
print("=" * 70)

# Set task output values
dbutils.jobs.taskValues.set(key="lineage_validated", value=all_valid)
dbutils.jobs.taskValues.set(key="validation_summary", value=f"{len(validation_results)} checks, {'all passed' if all_valid else 'some failed'}")
dbutils.jobs.taskValues.set(key="table_name", value=table_name)
dbutils.jobs.taskValues.set(key="row_count", value=actual_row_count)
dbutils.jobs.taskValues.set(key="distinct_stocks", value=distinct_stocks)
dbutils.jobs.taskValues.set(key="date_range", value=f"{min_date} to {max_date}")

print(f"\nTask output values set: lineage_validated={all_valid}")

# Fail fast if any validation check failed
if not all_valid:
    failed_checks = [r["check"] for r in validation_results if not r["passed"]]
    raise RuntimeError(f"Lineage validation FAILED. Failed checks: {failed_checks}")
else:
    print("Lineage validation PASSED - all checks completed successfully!")