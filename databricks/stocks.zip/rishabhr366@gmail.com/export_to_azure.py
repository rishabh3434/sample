# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Title
# MAGIC %md
# MAGIC # Export Stock Data to Azure
# MAGIC
# MAGIC Exports transformed stock data from the stock_daily_data table to Azure Data Lake Storage in Parquet format

# COMMAND ----------

# DBTITLE 1,Environment Configuration
# Create widgets for configuration
dbutils.widgets.text("environment", "dev", "Environment")
dbutils.widgets.text("azure_path", "abfss://container@storageaccount.dfs.core.windows.net/stock_data", "Azure Storage Path")

# Get configuration values
environment = dbutils.widgets.get("environment")
azure_path = dbutils.widgets.get("azure_path")

# Print configuration
print(f"Environment: {environment}")
print(f"Azure Storage Path: {azure_path}")
print(f"Source Table: {environment}.stock_daily_data")

# COMMAND ----------

# DBTITLE 1,Read Data from Table
# Get widget values
environment = dbutils.widgets.get("environment")

# Read data from the stock_daily_data table
table_name = f"{environment}.stock_daily_data"

print(f"Reading data from {table_name}...")
df = spark.table(table_name)

# Show basic info
row_count = df.count()
print(f"Total rows to export: {row_count:,}")
print(f"\nSchema:")
df.printSchema()

# COMMAND ----------

# DBTITLE 1,Export to Azure Storage
# Get widget values
azure_path = dbutils.widgets.get("azure_path")

# Export data to Azure Data Lake Storage in Parquet format
try:
    print(f"Writing data to {azure_path}...")
    
    # Write to Azure with partitioning by Stock symbol
    df.write \
        .mode("overwrite") \
        .partitionBy("Stock") \
        .parquet(azure_path)
    
    print(f"\n✓ Successfully exported {row_count:,} rows to Azure Storage")
    print(f"  Location: {azure_path}")
    print(f"  Format: Parquet")
    print(f"  Partitioned by: Stock")
    
except Exception as e:
    print(f"\n✗ Error exporting data to Azure: {str(e)}")
    print(f"\nNote: This error is expected if Azure credentials are not configured.")
    print(f"To configure Azure access, set up:")
    print(f"  - Service principal credentials, OR")
    print(f"  - Storage account access key, OR")
    print(f"  - SAS token")
    raise